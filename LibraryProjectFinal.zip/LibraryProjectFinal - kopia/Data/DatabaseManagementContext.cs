﻿using Microsoft.EntityFrameworkCore;

namespace LibraryProjectFinal.Data
{
    public class DatabaseManagementContext : DbContext
    {

        public DbSet<Employees> Employees { get; set; }
        public DbSet<LibraryItem> LibraryItems { get; set; }
        public DbSet<Category> Category { get; set; }

        public DatabaseManagementContext(DbContextOptions<DatabaseManagementContext> options) : base(options)
        {
            Database.EnsureCreated();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasMany(c => c.LibraryItem).WithOne(l => l.Category);

            modelBuilder.Entity<Category>().HasData(GetCategorySeededData());
            modelBuilder.Entity<LibraryItem>().HasData(GetLibraryItemSeededData());
            modelBuilder.Entity<Employees>().HasData(GetEmployeesSeededData());

            base.OnModelCreating(modelBuilder);
        }
        private List<Category> GetCategorySeededData()
        {

            List<Category> category = new List<Category>() { new Category() { Id = 1, CategoryName = "Fantasy" }, new Category() { Id = 2, CategoryName = "Classics" } };

            return category;
        }
        private List<LibraryItem> GetLibraryItemSeededData()
        {
            List<LibraryItem> libraryitem = new List<LibraryItem>(){ new LibraryItem() { Id = 1, CategoryId = 1, Title = "Harry Potter" , Author = "J.K.Rowling ", Pages = 350 , RunTimeMinutes = 0, IsBorrowable = true , Borrower = "Ken Jones", BorrowDate = 220202 ,Type = "Book" },
                                                          new LibraryItem(){ Id = 2, CategoryId = 2, Title = "Gösta Berlings saga" , Author= "Selma Lagerlof ", Pages = 300 , RunTimeMinutes = 0, IsBorrowable = true , Borrower = "Anna Birdly", BorrowDate = 220202 ,Type = "Book" } };
            return libraryitem;
        }

        private List<Employees> GetEmployeesSeededData()
        {
            List<Employees> employees = new List<Employees>(){ new Employees() { Id = 1 , FirstName = "Ana", LastName = "Bäckström", Salary = 34000.5M , IsCEO = false, IsManager = true, ManagerId = 1 },
                                                            new Employees{ Id = 2 , FirstName = "Kevin", LastName = "Trajkovski", Salary = 30000.5M , IsCEO = false, IsManager = false, ManagerId = 0 } };
            return employees;
        }




    }
}
