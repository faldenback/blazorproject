﻿using System.ComponentModel.DataAnnotations;

namespace LibraryProjectFinal.Data
{
    public class Category
    {
        public int Id { get; set; }

        [Required]
        [StringLength(20, ErrorMessage = "{0} length must be between {2} and {1}", MinimumLength = 3)]
        public string CategoryName { get; set; }

        public ICollection<LibraryItem> LibraryItem { get; set; }
        public Category()
        {
            LibraryItem = new List<LibraryItem>();
        }

    }
}
