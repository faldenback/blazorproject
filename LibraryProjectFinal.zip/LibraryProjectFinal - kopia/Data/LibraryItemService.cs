﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace LibraryProjectFinal.Data
{
	public class LibraryItemService
	{
		private readonly DatabaseManagementContext _context; 

		public LibraryItemService(DatabaseManagementContext context)
		{
			_context = context;	
		}

        public async Task<List<LibraryItem>> GetLibraryItemAsync()
        {
            return await _context.LibraryItems.ToListAsync();
        }

        public async Task<LibraryItem> AddLibraryItemAsync(LibraryItem lib)
        {
           try
            {
                _context.LibraryItems.Add(lib);
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw;
            }
            return lib;
        }

        public async Task<LibraryItem> DeleteLibraryItemAsync(LibraryItem lib)
        {
           try
            {
                _context.LibraryItems.Remove(lib);
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw;
            }
           return lib;
        }



    }
}
