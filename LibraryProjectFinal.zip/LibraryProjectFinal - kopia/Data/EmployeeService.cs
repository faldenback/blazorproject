﻿using Microsoft.EntityFrameworkCore;
using SQLitePCL;
using System.Collections.Generic;

namespace LibraryProjectFinal.Data
{
    public class EmployeeService
    {
        private readonly DatabaseManagementContext _context;

        public EmployeeService(DatabaseManagementContext context)
        {
            _context = context;
        }

        public async Task<List<Employees>>GetEmployeesAsync()
        {
            return await _context.Employees.ToListAsync();
        }

        public async Task<Employees>AddEmployeesAsync(Employees emp)
        {
            try
            {
                _context.Employees.Add(emp);
                await _context.SaveChangesAsync();
            }
            catch(Exception e)
            {
                throw;
            }
            return emp;
        }

        public async Task<Employees> DeleteEmployeesAsync(Employees emp)
        {
            try
            {
                _context.Employees.Remove(emp);
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw;
            }
            return emp;
        }

    }
}
