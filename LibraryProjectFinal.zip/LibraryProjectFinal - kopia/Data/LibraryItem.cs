﻿using System.ComponentModel.DataAnnotations;

namespace LibraryProjectFinal.Data
{
    public class LibraryItem
    {
        public int Id { get; set; }

        [Required]
        [StringLength(20, ErrorMessage = "{0} length must be between {2} and {1}", MinimumLength = 3)]
        public string Title { get; set; }
        [Required]
        [StringLength(20, ErrorMessage = "{0} length must be between {2} and {1}", MinimumLength = 3)]
        public string Author { get; set; }
        [Range(0,5000)]
        public int Pages { get; set; }
        [Range(0,5000)]
        public int RunTimeMinutes { get; set; }
        [Required]
        public bool IsBorrowable { get; set; }
        [Required]
        [StringLength(20, ErrorMessage = "{0} length must be between {2} and {1}", MinimumLength = 3)]
        public string Borrower { get; set; }
        public int CategoryId { get; set; }
        public Category Category { get; set; }

        public int BorrowDate { get; set; }

        [Required]
        public string Type { get; set; }

        public LibraryItem()
        {

        }

    }
}
