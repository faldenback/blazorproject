﻿using Microsoft.EntityFrameworkCore;

namespace LibraryProjectFinal.Data
{
    public class CategoryService
    {
        private readonly DatabaseManagementContext _context;

        public CategoryService(DatabaseManagementContext context)
        {
            _context = context;
        }

        public async Task<List<Category>> GetCategoryAsync()
        {
            return await _context.Category.ToListAsync();
        }

        public async Task<Category> AddCategoryAsync(Category cat)
        {
            try
            {
                _context.Category.Add(cat);
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw;
            }
            return cat;
        }

        public async Task<Category> DeleteCategoryAsync(Category cat)
        {
            try
            {
                _context.Category.Remove(cat);
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw;
            }
            return cat;
        }



    }
}
