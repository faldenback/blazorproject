﻿using System.ComponentModel.DataAnnotations;

namespace LibraryProjectFinal.Data
{
    public class Employees
    {
        public int Id { get; set; }

        [Required]
        [StringLength(20, ErrorMessage = "{0} length must be between {2} and {1}", MinimumLength = 3)]
        public string FirstName { get; set; }

        [Required]
        [StringLength(20, ErrorMessage = "{0} length must be between {2} and {1}", MinimumLength = 3)]
        public string LastName { get; set; }
        [Required]
        [Range(8000,70000)]
        public decimal Salary { get; set; }
        [Required]
        public bool IsCEO { get; set; }
        [Required]
        public bool IsManager { get; set; }
        public int ManagerId { get; set; } 

        public Employees()
        {
            
        }
    }
}
